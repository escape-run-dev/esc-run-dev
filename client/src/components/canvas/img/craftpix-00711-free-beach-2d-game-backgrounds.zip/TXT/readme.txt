Bear Hugs
https://www.dafont.com/bear-hugs.font